import axios from "axios";

// export default axios.create({
//     baseURL:'https://soccer-store-5b1b3-default-rtdb.firebaseio.com/'
// })

export const BASE_URL: string =
  "https://soccer-store-5b1b3-default-rtdb.firebaseio.com";

