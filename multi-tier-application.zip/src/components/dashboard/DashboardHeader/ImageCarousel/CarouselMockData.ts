import img1 from "../../../../assets/images/sliderImages/img1.png";
import img2 from "../../../../assets/images/sliderImages/img2.png";
import img3 from "../../../../assets/images/sliderImages/img3.png";
export const ImageCarouselData = [
  { id: 1, image: img1 },
  { id: 2, image: img2 },
  { id: 3, image: img3 },
];
