import React from "react";
import { Box } from "@mui/material";
import DashboardHeader from "./DashboardHeader/DashboardHeader";
const Dashboard = () => {
  return (
    <Box sx={{background:'green'}}>
      <DashboardHeader />
    </Box>
  );
};

export default Dashboard;
