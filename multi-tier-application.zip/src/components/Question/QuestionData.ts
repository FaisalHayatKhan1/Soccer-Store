export const QuestionData = [
  {
    id: 1,
    question:
      "filter1",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 2,
    question:
      "filter2",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 3,
    question:
      "filter3",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 4,
    question:
      "filter4",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 5,
    question:
      "filter5",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 6,
    question:
      "filter6",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 7,
    question:
      "filter7",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
  {
    id: 8,
    question:
      "filter8",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab ipsam tempora accusamus doloribus aliquid aspernatur culpa molestias, reprehenderit magnam eligendi eos, tenetur atque molestiae.",
  },
];
