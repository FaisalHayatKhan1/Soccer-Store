import * as yup from "yup";

export const ContactUsSchema = yup.object({
  productName: yup.string().required("Product Name is Required"),
  category: yup.string().required("Catagory is Required"),
  price: yup.string().required("Price is Required"),
//   image: yup.string().required("image is Required"),
  // productSize: yup.string().required("Add sizes"),
});

export const ContactUsInitialValues = {
  productName: "",
  category: "",
  price: "",
  image: "",
  productSize: [],
};
