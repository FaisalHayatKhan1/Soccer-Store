import React from "react";

const ProductHistory = () => {
  return <div>ProductHistory</div>;
};

export default ProductHistory;
